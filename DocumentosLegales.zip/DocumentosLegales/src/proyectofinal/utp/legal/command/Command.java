package proyectofinal.utp.legal.command;

public interface Command {
    void execute();
    String name();
}
