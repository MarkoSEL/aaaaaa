package proyectofinal.utp.legal.decorator;

public class BaseBadge implements Badge {
    @Override public String render() { return ""; }
}
