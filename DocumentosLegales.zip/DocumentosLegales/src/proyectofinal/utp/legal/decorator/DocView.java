package proyectofinal.utp.legal.decorator;

public interface DocView {
    String render();
}
