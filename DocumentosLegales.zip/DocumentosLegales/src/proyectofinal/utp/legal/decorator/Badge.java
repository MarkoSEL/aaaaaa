package proyectofinal.utp.legal.decorator;

public interface Badge {
    String render(); // HTML corto
}
