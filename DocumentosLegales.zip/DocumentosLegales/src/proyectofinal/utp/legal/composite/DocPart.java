package proyectofinal.utp.legal.composite;

public interface DocPart {
    // level es el nivel de indentacion (0 = raiz)
    String render(int level);
}
